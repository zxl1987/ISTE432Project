class DataInterface:
    def allData(self): pass
