class userInfo:
    userId = None
    username=None
    password=None
    firstname=None
    lastname = None
    email = None
    birth = None
    homeaddress = None

    def setUserid(self, id):
        self.userId = id

    def getUserid(self):
        return self.userId

    


